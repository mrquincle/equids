#define PRINTF_SUPPORT 
#define MAX_PERMISSIBLE_ERROR  0
segment ("mydata1") unsigned char input[64];
segment ("mydata1") unsigned char output[64];
unsigned char zero_in = 0;
unsigned char one_in = 1;
unsigned char output1[64]={0,0,0,0,0,0,0,0,
                           0,1,1,1,1,1,1,0,
                           0,1,0,0,0,0,1,0,
                           0,1,0,0,0,0,1,0,
                           0,1,0,0,0,0,1,0,
                           0,1,0,0,0,0,1,0,
                           0,1,1,1,1,1,1,0,
                           0,0,0,0,0,0,0,0};



unsigned char output2[64]={0,0,0,0,0,0,0,0,
                           0,1,1,1,1,1,1,0,
                           0,1,0,0,0,1,0,0,
                           0,1,0,0,1,0,0,0,
                           0,1,0,1,0,0,0,0,
                           0,1,1,0,0,0,0,0,
                           0,1,0,0,0,0,0,0,
                           0,0,0,0,0,0,0,0};


