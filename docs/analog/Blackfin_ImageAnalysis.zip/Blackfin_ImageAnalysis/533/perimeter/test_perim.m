clear
fp=fopen('woman1.dat','rb');
a=fread(fp);
a1=reshape(a,256,256);
szx=256;
szy=256;
b=bwmorph(a1,'perim4');
b=double(b);
imagesc(b')
colormap(gray)
b=b';
fp1=fopen('expected_perim.dat','wb');
for i=1:szx
   for j=1:szy
      fprintf(fp1,'%c',b(i,j));
   end
end
      
fclose(fp);
fclose(fp1);