/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************

#define INSIZE  256*256   // Image size
segment ("data1") unsigned char PtrInput[INSIZE];
segment ("data1") unsigned char PtrOutput[INSIZE];
segment("data1") unsigned char out[INSIZE];

FILE *ptr, *ptr1;

main (void)
{

    short row, col;
   int i, nTotalPixel,j,k,l;

// Input image is generated using matlab
    ptr = fopen("input_med.dat","rb");

    if(ptr == NULL)
    {
        printf("unable to open ptr\n");
    }
// file to store the output image 
    ptr1 = fopen("m_res.dat", "wb");

    if(ptr1 == NULL)
    {
        printf("unable to open ptr1\n");
    }

    row = 256;
    col = 256;

    nTotalPixel = row * col;
    fread(PtrInput,sizeof(char),nTotalPixel,ptr);

    _median(PtrInput,row,col,PtrOutput);

  
 fwrite(PtrOutput,sizeof(char),nTotalPixel,ptr1);
  fclose(ptr1);
  fclose(ptr);
}
