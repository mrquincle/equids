 /*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
  File name   : t_median.c
  Purpose     : This function tests the median function.
******************************************************************************/ 
#include<stdio.h>
#include"median.h"

int error_flag=0;
void (*f1)();
int cycle_count[10];
void _median();

main()
{
    int i,j,k;
    float f;
    int row,col,error;

    f1 = _median;
    row=8;
    col=8;

// test 1:  Input 8x8 matrix , SE==N4 (neighboring 4)

    cycle_count[0] = Compute_Cycle_Count(input1,row,col,output);  
                            //This function inturn calls median()

    for(i=0;i<64;i++)
    {
        error=output[i]-output1[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 1;
        }
   }

// test 2:

    row=8;
    col=16;

    cycle_count[1] = Compute_Cycle_Count(input2,row,col,output);      
                            //This function inturn calls median()

    for(i=0;i<row*col;i++)
    {
        error=output[i]-output2[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 2;
        }
    }
    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
        if(error_flag & 2)
            printf("Test Case 2 failed\n");
        else
            printf("Test Case 2 passed\n");
    #endif
    
    printf("cycle_count[0]=%d,cycle_count[1]=%d\n",cycle_count[0],cycle_count[1]);
    
}

