N1 = 256; N2 = 256;
FID1 = fopen('test_image.dat');
I = fread(FID1,[N1,N2],'uchar');
figure;
imagesc(I');colormap(gray);

