/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
  Func name   : t_skeleton.c
  Purpose     : This function tests the skeleton function using an image.
******************************************************************************/ 
#include<stdio.h>
#include"skeleton.h"

int error_flag=0;
void (*f1)();
int cycle_count[15];
void _skeleton();

main()
{
    int i,j,k;
    float f;
    int row,col,error;

    f1 = _skeleton;     
    row=8;
    col=8;

    for(i=0;i<row*col;i++)
        output[i]=zero_in;

// test 1:  square input

    cycle_count[0] = Compute_Cycle_Count(input1,row,col,res,output);  
                            //This function inturn calls skeleton()

    cycle_count[1] = Compute_Cycle_Count(res,row,col,res1,output);    
                            //This function inturn calls skeleton()

    cycle_count[2] = Compute_Cycle_Count(res1,row,col,res,output);    

    cycle_count[3] = Compute_Cycle_Count(res,row,col,res1,output);    

    
    for(i=0;i<row*col;i++)
    {
        error=output[i]-exp_output1[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 1;
        }
    }

// test2 : Circle

    for(i=0;i<row*col;i++)
        output[i]=zero_in;

    cycle_count[4] = Compute_Cycle_Count(input2,row,col,res,output);
    cycle_count[5] = Compute_Cycle_Count(res,row,col,res1,output);
    cycle_count[6] = Compute_Cycle_Count(res1,row,col,res,output);
    cycle_count[7] = Compute_Cycle_Count(res,row,col,res1,output);
    cycle_count[8] = Compute_Cycle_Count(res1,row,col,res,output);
                    
    for(i=0;i<row*col;i++)
    {
        error=output[i]-exp_output2[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 2;
        }
    }

// test3 : L shape input

    row=16;
    col=16;

    for(i=0;i<row*col;i++)
        output[i]=zero_in;

    cycle_count[9] = Compute_Cycle_Count(input3,row,col,res,output);
    cycle_count[10] = Compute_Cycle_Count(res,row,col,res1,output);
    cycle_count[11] = Compute_Cycle_Count(res1,row,col,res,output);
    cycle_count[12] = Compute_Cycle_Count(res,row,col,res1,output);
    cycle_count[13] = Compute_Cycle_Count(res1,row,col,res,output);
                    
    for(i=0;i<row*col;i++)
    {
        error=output[i]-exp_output3[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 4;
        }
    }
    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
        if(error_flag & 2)
            printf("Test Case 2 failed\n");
        else
            printf("Test Case 2 passed\n");
        if(error_flag & 4)
            printf("Test Case 3 failed\n");
        else
            printf("Test Case 3 passed\n");
    #endif
    
    printf("cycle_count[0]=%d,cycle_count[1]=%d,cycle_count[2]=%d\n",cycle_count[0],cycle_count[1],cycle_count[2]);
    

}

