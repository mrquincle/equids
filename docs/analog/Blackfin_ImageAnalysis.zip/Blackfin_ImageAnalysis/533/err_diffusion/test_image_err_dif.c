/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************

#define INSIZE  256*256   // Image size
segment ("data1") unsigned char PtrInput[INSIZE];
segment ("data1") unsigned char PtrOutput[INSIZE];
segment("data1") unsigned char out[INSIZE];
segment("data1") short temp[257]; // column+1

FILE *ptr, *ptr1;

main (void)
{

    short row, col;
   int i, nTotalPixel,j,k,l;
   int thresh;

// Input image is generated using matlab
    ptr = fopen("test_input_err_dif.dat","rb");

    if(ptr == NULL)
    {
        printf("unable to open ptr\n");
    }
// file to store the output image 
    ptr1 = fopen("err_out.dat", "wb");

    if(ptr1 == NULL)
    {
        printf("unable to open ptr1\n");
    }
    for(i=0;i<257;i++)
        temp[i]=0;

    row = 256;
    col = 256;
    thresh=120;

    nTotalPixel = row * col;
    fread(PtrInput,sizeof(char),nTotalPixel,ptr);

    _err_dif(PtrInput,row,col,temp,PtrOutput,thresh );

  
 fwrite(PtrOutput,sizeof(char),nTotalPixel,ptr1);
  fclose(ptr1);
  fclose(ptr);
}
