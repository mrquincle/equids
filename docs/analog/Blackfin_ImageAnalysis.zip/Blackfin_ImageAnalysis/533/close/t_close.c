/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
  File name   : t_close.c
  Purpose     : This function tests the close function,
*******************************************************************************/
#include<stdio.h>
#include"close.h"

int error_flag = 0;
void (*f1)();
int cycle_count[10];
void _close();

main()
{
    int i,j,k;
    float f;
    int row,col,error;

    f1 = _close;        
    row = 8;
    col = 8;

// test 1:  Input 8x8 matrix , SE==N4 (neighboring 4)

    cycle_count[0] = Compute_Cycle_Count(input1,row,col,se0,output);
                            //This function inturn calls close()

    for(i=0;i<64;i++)
    {
        error=output[i]-output1[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 1;
        }
   }

// test 2: with SE=N8 (neighboring 8 )

    cycle_count[1] = Compute_Cycle_Count(input1,row,col,se1,output);
                            //This function inturn calls close()
    for(i=0;i<64;i++)
    {
        error=output[i]-output2[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 2;
        }
   }

// test 3: Input matrix 8x16  N4 structured element

    row = 8;
    col = 16;

    cycle_count[2] = Compute_Cycle_Count(input2,row,col,se0,output); 
                            //This function inturn calls close()
    for(i=0;i<8*16;i++)
    {
        error=output[i] - output3[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
           
            error_flag = error_flag | 4;
        }
   }

// test4 : Input 8x16 matrix  N8 structured element

    cycle_count[3] = Compute_Cycle_Count(input2,row,col,se1,output);
                            //This function inturn calls close()

    for(i=0;i<8*16;i++)
    {
        error=output[i]-output4[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 8;
        }
   }
    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
        if(error_flag & 2)
            printf("Test Case 2 failed\n");
        else
            printf("Test Case 2 passed\n");
        if(error_flag & 4)
            printf("Test Case 3 failed\n");
        else
            printf("Test Case 3 passed\n");
        if(error_flag & 8)
            printf("Test Case 4 failed\n");
        else
            printf("Test Case 4 passed\n");
    #endif
    
    printf("cycle_count[0]=%d,cycle_count[1]=%d,cycle_count[2]=%d,cycle_count[3]=%d\n",cycle_count[0],cycle_count[1],cycle_count[2],cycle_count[3]);
    

}

