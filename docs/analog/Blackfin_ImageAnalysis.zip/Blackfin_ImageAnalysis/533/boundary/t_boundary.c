/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
  File name   : t_boundary.c
  Purpose     : This file tests the boundary function 
*******************************************************************************/
#include<stdio.h>
#include "boundary.h"

int error_flag = 0;
void (*f1)();
int cycle_count[10];
void _boundary();

main()
{
    int i,j,k;
    float f;
    int row,col,error,error1;

    f1 = _boundary; 

    row=8;
    col=8;

// test 1:  Input 8x8 matrix 

    for(i=0;i<row;i++)
        for(j=0;j<col;j++)
            input[i*col+j]=zero_in;

    for(i=1;i<7;i++)
        for(j=1;j<7;j++)
            input[i*col+j]=const_data1;

    cycle_count[0] = Compute_Cycle_Count(input,row,col,xy,output);
                            //This function inturn calls _boundary()

    for(i=0;i<36;i++)
    {
       error=xy[i]-XY1[i];
       if(error < 0) error = -error;
       error1=output[i]-10;
       if(error1 < 0) error1 = -error1;
        
       if(error > MAX_PERMISSIBLE_ERROR | error1 > MAX_PERMISSIBLE_ERROR)
       {
            error_flag = error_flag | 1;
            break;
        }
   }

// test 2 :

    cycle_count[1] = Compute_Cycle_Count(input1,row,col,xy,output);

    for(i=0;i<31;i++)
    {
        error=xy[i]-XY2[i];
        if(error < 0) error = -error;
        error1=output[i]-output1[i];
        if(error1 < 0) error1 = -error1;
        
       if(error > MAX_PERMISSIBLE_ERROR | error1 > MAX_PERMISSIBLE_ERROR)
       {
            error_flag = error_flag | 2;
            break;
        }
   }
    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
        if(error_flag & 2)
            printf("Test Case 2 failed\n");
        else
            printf("Test Case 2 passed\n");
    #endif
    
    printf("cycle_count[0]=%d,cycle_count[1]=%d\n",cycle_count[0],cycle_count[1]);
    

}

