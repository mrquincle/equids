/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************

#define INSIZE  6336   // Image size== 72 x88
segment ("data1") unsigned char PtrInput[INSIZE];
segment ("data1") unsigned char PtrOutput[INSIZE];
segment("data1")  int XY[INSIZE];
segment("data1") unsigned char out[INSIZE];

FILE *ptr, *ptr1;

main (void)
{

    short row, col;
   int i, nTotalPixel,j,k,l;


    ptr = fopen("weather.dat","rb");

    if(ptr == NULL)
    {
        printf("unable to open ptr\n");
    }

    ptr1 = fopen("b_res.dat", "wb");

    if(ptr1 == NULL)
    {
        printf("unable to open ptr1\n");
    }

    row = 72;
    col = 88;

    nTotalPixel = row * col;
    fread(PtrInput,sizeof(char),nTotalPixel,ptr);
// boundary function called
    _boundary(PtrInput,row,col,XY,PtrOutput);

// clear the array to get image back      
    for(i=0;i<nTotalPixel;i++)
        out[i]=0;
       
    i=0;
    while(PtrOutput[i] !=0)
    {
        j=XY[i];          // get XY co-ordinate value
        k=j;
        j>>=16;           // get X co-ordinate
        k<<=16;      
        k>>=16;           // get Y co-ordinate
        l=j*col+k;        // get exact position
        out[l]=PtrOutput[i];// store the pixel value at proper location
        i++;               // to  fetch next value and co-ordinates
    }
     
 fwrite(out,sizeof(char),nTotalPixel,ptr1);
  fclose(ptr1);
  fclose(ptr);
}
