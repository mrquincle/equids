/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************

#include <stdio.h>
#include <math.h>

#define INSIZE  256*256


segment ("data1") unsigned char PtrInput[INSIZE];
segment ("data1") unsigned char PtrOutput[INSIZE];


FILE *ptr, *ptr1;

main (void)
{

    short row, col;
     int j,k,l;
    int i, nTotalPixel;


    ptr = fopen("woman.dat","rb");

    if(ptr == NULL)
    {
        printf("unable to open ptr\n");
    }

    ptr1 = fopen("re.dat", "wb");


    if(ptr1 == NULL)
    {
        printf("unable to open ptr1\n");
    }

    row = 256;
    col = 256;

    nTotalPixel = row * col;
    fread(PtrInput,sizeof(char),nTotalPixel,ptr);


// threshold ==321 for woman.dat  ,calculated using matlab
    _sobel(PtrInput,row,col,PtrOutput,322);

     fwrite(PtrOutput,sizeof(char),nTotalPixel,ptr1);

    
   fclose(ptr1);
   fclose(ptr);
}
