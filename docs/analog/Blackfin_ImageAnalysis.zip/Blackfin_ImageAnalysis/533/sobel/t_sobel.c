/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
  Func name   : t_sobel.c
  Description : This function tests the sobel function.
*****************************************************************************/ 
#include<stdio.h>
#include"sobel.h"

int error_flag = 0;
void (*f1)();
int cycle_count[15];
void _sobel();

main()
{
    int i,j,k;
    float f;
    int row,col,error;
    unsigned char output_sbl[32*32];
    
    f1 = _sobel;        
    row=32;
    col=32;

// test 1: Threshold value is calculated using matlab

    for(i=0;i<row*col;i++)
        input1[i] = zero_in;


    for(i=2;i<28;i++)
        for(j=2;j<28;j++)
            input1[i*col+j]=const_data1;

    cycle_count[0] = Compute_Cycle_Count(input1,row,col,output_sbl,966);  
                            //This function inturn calls sobel()
    
    for(i=0;i<row*col;i++)
    {
        error=output_sbl[i]-exp_out1[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 1;
        }
   }

   row=8;
   col=16;
  
 // test 2:

    cycle_count[1] = Compute_Cycle_Count(input2,row,col,output_sbl,279);  
                            //This function inturn calls sobel()

    for(i=0;i<row*col;i++)
    {
        error=output_sbl[i]-exp_out2[i];
        if(error < 0) error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 2;
        }
    }
    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
        if(error_flag & 2)
            printf("Test Case 2 failed\n");
        else
            printf("Test Case 2 passed\n");
        if(error_flag & 4)
            printf("Test Case 3 failed\n");
        else
            printf("Test Case 3 passed\n");
    #endif
    
    printf("cycle_count[0]=%d,cycle_count[1]=%d,cycle_count[2]=%d\n",cycle_count[0],cycle_count[1],cycle_count[2]);
    
}

