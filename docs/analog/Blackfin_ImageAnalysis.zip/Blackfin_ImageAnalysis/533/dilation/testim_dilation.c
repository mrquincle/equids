/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
******************************************************************************/ 
#include <stdio.h>
#include <math.h>
#include "dilation.h"

#define INSIZE  65536
segment ("data1") unsigned char PtrInput[INSIZE];
segment ("data1") unsigned char PtrOutput[INSIZE];
FILE *ptr, *ptr1;

main (void)
{

    short row, col;
    int i, nTotalPixel;

    ptr = fopen("woman1.dat", "rb");

    if(ptr == NULL)
    {
        printf("unable to open ptr\n");
    }

    ptr1 = fopen("dilate_res.dat", "wb");


    if(ptr1 == NULL)
    {
        printf("unable to open ptr1\n");
    }

    row = 256;
    col = 256;

    nTotalPixel = row * col;
    fread(PtrInput,sizeof(char),nTotalPixel,ptr);

// N4 structred element is used   

    _dilation(PtrInput,row,col,se0,PtrOutput);
      
      
     fwrite(PtrOutput,sizeof(char),nTotalPixel,ptr1);

    
   fclose(ptr1);
   fclose(ptr);
}
