/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
  Purpose     : This function tests the Histogram Equalization function using an image data.
                 
******************************************************************************/ 
#include <stdio.h>
#include <math.h>

#define INSIZE 65536
#define ROW 256
#define COL 256

segment ("data1") unsigned char PtrInput[INSIZE];
segment ("data1") unsigned char PtrOutput[INSIZE];


extern void _hist_eq(unsigned char* PtrInput,unsigned char* PtrOutput,int nTotalPixel, short nBins);


FILE *ptr, *ptr1;

main (void)
{
    short nBins=256;

    int nTotalPixel;


    ptr = fopen("baboon256.dat", "rb");

    if(ptr == NULL)
    {
        printf("unable to open input file ptr\n");
    }

    ptr1 = fopen("hist_trial.dat", "wb");


    if(ptr1 == NULL)
    {
        printf("unable to open output file ptr\n");
    }


    nTotalPixel = ROW * COL;

    fread(PtrInput, sizeof(unsigned char), nTotalPixel, ptr);

     _hist_eq(PtrInput, PtrOutput, nTotalPixel, nBins);

    fwrite(PtrOutput, sizeof(unsigned char),nTotalPixel,ptr1);

   fclose(ptr1);
   fclose(ptr);
}
