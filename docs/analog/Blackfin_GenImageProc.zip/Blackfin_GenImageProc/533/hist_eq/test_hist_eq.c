/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
File Name      : test_hist_eq.c
Description    : This module tests the histogram equalization routine in 
                 hist_eq.asm 
*******************************************************************************/
#include <stdio.h>
#include "histvalues.h"

extern void _hist_eq(unsigned char* PtrInput,unsigned char* PtrOutput,
                     int nTotalPixels, short nBins);

int error_flag = 0;
void (*f1)();
int cycle_count[10];

main()
{
    int i,error;
    int nTotalPixels;
    short nBins;

    f1 = (void(*)()) _hist_eq;

    /* Test case : 1 */
    
    nTotalPixels=26;
    nBins = 5;

    for(i=0;i<nTotalPixels;i++)
    {
        PtrInput[i] = TestInput1[i];
    }

    cycle_count[0] = Compute_Cycle_Count(PtrInput, PtrOutput, nTotalPixels,
                                         nBins);
                                        //This function inturn calls hist_eq()

    for(i=0;i<nTotalPixels;i++)
    {
        error = abs(OutputExpd1[i] - PtrOutput[i]);
        if(error >= MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 1;
        }
    }

    /*  Test case : 2  */
     
    nTotalPixels=26;
    
    nBins = 10;

    for(i=0;i<nTotalPixels;i++)
    {
        PtrInput[i] = TestInput2[i];
    }

    cycle_count[1] = Compute_Cycle_Count(PtrInput, PtrOutput, nTotalPixels,
                                        nBins);
                                    //This function inturn calls hist_eq()

    for(i=0;i<nTotalPixels;i++)
    {
        error=abs(OutputExpd2[i] - PtrOutput[i]);

        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 2;
        }
    }

     /* Test case : 3 */ 
     
    nTotalPixels=34;
    
    nBins = 30;

    for(i=0;i<nTotalPixels;i++)
    {
        PtrInput[i] = TestInput3[i];
    }

    cycle_count[2] = Compute_Cycle_Count(PtrInput, PtrOutput, nTotalPixels,
                                         nBins);
                                        //This function inturn calls hist_eq()

    for(i=0;i<nTotalPixels;i++)
    {
        error=abs(OutputExpd3[i] - PtrOutput[i]);

        if(error > MAX_PERMISSIBLE_ERROR)
        {
            error_flag = error_flag | 4;
        }
    }

    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
        if(error_flag & 2)
            printf("Test Case 2 failed\n");
        else
            printf("Test Case 2 passed\n");
        if(error_flag & 4)
            printf("Test Case 3 failed\n");
        else
            printf("Test Case 3 passed\n");
    #endif
    
    printf("cycle_count[0]=%d,cycle_count[1]=%d,cycle_count[2]=%d\n",cycle_count[0],cycle_count[1],cycle_count[2]);
    
}

