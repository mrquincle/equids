for x = 1 :8
   for y = 1:8
      f(x, y) = ((x-1) - (y-1))*100;
   end
end  
fid = fopen('baboon256.dat','r');
[X, count] = fread(fid, [256, 256], 'uchar');
figure;
colormap(gray);
fig1 = imagesc(X');

fid = fopen('hist_trial.dat','r');
[X, count] = fread(fid, [256, 256], 'uchar');
figure;
colormap(gray);
fig2 = imagesc(X');