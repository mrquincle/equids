/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
File Name    :  Test_conv2d3x3_gen.c
Description  :  This function tests _conv2d3x3_gen with 4 test cases and finds 
                cycle count for input sizes of 3x3, 5x5, 5x7 and 16x16.
    1. Test1 - Random test with output not overflowing i/p = 3 x 3
    2. Test2 - Random test with output not overflowing i/p = 5 x 5
    3. Test3 - Random test with output overflowing(saturated) i/p = 5 x 5
    4. Test4 - Random test with output not overflowing i/p = 16 x 16
*******************************************************************************/
#include "conv2d3x3_gen.h"
extern void _conv2d3x3_gen (fract16 in[], short row, short col, 
                            fract16 mask[], fract16 out[]);

int error_flag = 0;
void (*f1)();
int cycle_count[10];

void main (void)
{
    int row, col;
    int i, error;

    f1 = (void(*)()) _conv2d3x3_gen;    
                            // Function Pointer
// ************************************************************
// Test1 - Random test with output not overflowing i/p = 3 x 3
// ************************************************************
    row = 3, col = 3;   
        
    for(i=0; i<row*col; i++)    in[i] = in_3[i];
    for(i=0; i<9; i++)          mask[i] = mask_3[i];

    cycle_count[0] = Compute_Cycle_Count(in, row, col, mask, out);
                            // This function inturn calls _conv2d3x3_gen()

    for(i=0; i<row*col; i++)
    {
        error = out[i] - out_3[i];
        if (abs(error) > MAX_PERMISSIBLE_ERROR)
        {    
            error_flag = error_flag | 1;
            break;
        }
    }
// ************************************************************
// Test2 - Random test with output not overflowing i/p = 5 x 5
// ************************************************************
    row = 5, col = 5;   
        
    for(i=0; i<row*col; i++)    in[i] =in_s[i];
    for(i=0; i<9; i++)          mask[i]=mask_s[i];

    cycle_count[1] = Compute_Cycle_Count(in, row, col, mask, out);
                            // This function inturn calls _conv2d3x3_gen()

    for(i=0; i<row*col; i++)
    {
        error = out[i] - out_s[i];
        if (abs(error) > MAX_PERMISSIBLE_ERROR)
        {    
            error_flag = error_flag | 2;
            break;
        }
    }
// ****************************************************************
// Test3 - Random test with output overflowing(saturated) i/p = 5x5
// ****************************************************************
    row = 5, col = 5;   
        
    for(i=0; i<row*col; i++)    in[i] =in_of[i];
    for(i=0; i<9; i++)          mask[i]=mask_of[i];

    cycle_count[2] = Compute_Cycle_Count(in, row, col, mask, out);
                            // This function inturn calls _conv2d3x3_gen()

    for(i=0; i<row*col; i++)
    {
        error = out[i] - 0x7fff;
        if (abs(error) > MAX_PERMISSIBLE_ERROR)
        {    
            error_flag = error_flag | 4;
            break;
        }
    }
// ************************************************************
// Test4 - Random test with output not overflowing i/p = 16 x16
// ************************************************************
    row = 16, col = 16; 
        
    for(i=0; i<row*col; i++)    in[i] =in_16[i];
    for(i=0; i<9; i++)          mask[i]=mask_16[i];

    cycle_count[3] = Compute_Cycle_Count(in, row, col, mask, out);
                            // This function inturn calls _conv2d3x3_gen()

    for(i=0; i<row*col; i++)
    {
        error = out[i] - out_16[i];
        if (abs(error) > MAX_PERMISSIBLE_ERROR)
        {    
            error_flag = error_flag | 8;
            break;
        }
    }
    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
        if(error_flag & 2)
            printf("Test Case 2 failed\n");
        else
            printf("Test Case 2 passed\n");
        if(error_flag & 4)
            printf("Test Case 3 failed\n");
        else
            printf("Test Case 3 passed\n");
        if(error_flag & 8)
            printf("Test Case 4 failed\n");
        else
            printf("Test Case 4 passed\n");
    #endif
    
        printf("cycle_count[0]=%d,cycle_count[1]=%d,cycle_count[2]=%d\n,cycle_count[3]=%d",cycle_count[0],cycle_count[1],cycle_count[2],cycle_count[3]);

}

