/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
File Name       : Test_conv2d5x5_spl.c
Description     : This function tests _conv2d5x5_spl with input size of 16x16 
                  and finds cycle count for the same.
                1. Test1 - Random test with output not overflowing i/p = 16 x16
*******************************************************************************/
#include "conv2d5x5_spl.h"

extern void _conv2d5x5_spl(fract16 in[], short row, short col, fract16 mask[], 
                           fract16 out[]);
int error_flag = 0;
void (*f1)();
int cycle_count[10];

void main (void)
{
    int row, col;
    int i, error;

    f1 = (void(*)()) _conv2d5x5_spl;    // Function Pointer

// ************************************************************
// Test1 - Random test with output not overflowing i/p = 16 x 16
// ************************************************************
    row = 16, col = 16; 
        
    for(i=0; i<row*col; i++)    in[i] =in5_16[i];
    for(i=0; i<25; i++)         mask[i]=mask5_16[i];
    for(i=0; i<row*col; i++)    out[i] =1000;

    cycle_count[0] = Compute_Cycle_Count(in, row, col, mask, out);
                                //This function inturn calls conv2d5x5_spl()

    for(i=0; i<row*col; i++)
    {
        error = out[i] - out5_16[i];
        if (abs(error) > MAX_PERMISSIBLE_ERROR)
        {    
            error_flag = error_flag | 1;
        }
    }
    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
    #endif
    
    printf("cycle_count[0]=%d\n",cycle_count[0]);
    
}

