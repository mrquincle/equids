A:  To test the functionality of scale_up_by2 function

 To test the functionality of scale_up_by2 run scale_up.bat. It will create,run and  deletes the .DXE file
   
B:  Testing with image

* To test with image , mention the input file name, size and output filename in testim.c
* Run testim.bat 
* Edit encode_raw.m file , mention the size and name of the file to display as an image.
* run encode_raw.m file in MATLAB to view the image.


