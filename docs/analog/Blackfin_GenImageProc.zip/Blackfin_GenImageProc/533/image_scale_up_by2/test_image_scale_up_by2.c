/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
*******************************************************************************
File name   : test_image_scale_up_by2.c
Description : This file contains test cases to validate function 
              image_scale_up_by2().
*******************************************************************************/
#include<stdio.h>
#include "timage_scale_up_by2.h"

int error_flag = 0;
void (*f1)();
int cycle_count[10];

void _image_scale_up_by2();

main()
{
    int row,col;
    int i,j,k,l,mx,my;
    int error;

    f1 = _image_scale_up_by2;

    row=4;
    col=4;
    mx=2;my=2;

/* test 1:  using Bartlet window   */
   
    cycle_count[0] = Compute_Cycle_Count(input,row,col,coeff,out);
                              //This function inturn calls image_scale_up_by2()

   for(i=0;i<64;i++)
   {
       error=out[i]-out1[i];

       if(abs(error) >MAX_PERMISSIBLE_ERROR)
       {
            error_flag = error_flag | 1;
       }
   }

// test 2:  using Box window   
   
  cycle_count[1] = Compute_Cycle_Count(input,row,col,coeff1,out);
                               //This function inturn calls image_scale_up_by2()

   for(i=0;i<64;i++)
   {
       error=out[i]-out2[i];

       if(abs(error) >MAX_PERMISSIBLE_ERROR)
       {
            error_flag = error_flag | 2;
       }
   }

// test 3 :  with -ve coefficients in mask

    cycle_count[2] = Compute_Cycle_Count(input,row,col,coeff2,out);
                           //This function inturn calls image_scale_up_by2()

   for(i=0;i<64;i++)
   {
       error=out[i]-out3[i];

       if(abs(error) >MAX_PERMISSIBLE_ERROR)
       {
            error_flag = error_flag | 4;
       }
   }
    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
        if(error_flag & 2)
            printf("Test Case 2 failed\n");
        else
            printf("Test Case 2 passed\n");
        if(error_flag & 4)
            printf("Test Case 3 failed\n");
        else
            printf("Test Case 3 passed\n");
    #endif
    
    printf("cycle_count[0]=%d,cycle_count[1]=%d,cycle_count[2]=%d\n",cycle_count[0],cycle_count[1],cycle_count[2]);
    
}

