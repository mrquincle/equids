N1 = 512; N2 = 512;
FID1 = fopen('scale_Baoon.dat');
I = fread(FID1,[N1,N2],'uchar');
figure;
imagesc(I');colormap(gray);

