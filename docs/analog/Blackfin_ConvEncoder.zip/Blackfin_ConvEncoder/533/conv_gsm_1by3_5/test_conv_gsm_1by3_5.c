/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
File Name      : test_conv_gsm_1by3_5.c
Description    : This file contains the testing routine for
                 conv_gsm_1by3_5()
*******************************************************************************/
#include <stdio.h>
#include "tconv_gsm_1by3_5.h"
int error_flag = 0;
void (*f1)();
int cycle_count[10];
void _conv_gsm_1by3_5();

main()
{
    int m, i, a, error;

    f1 = _conv_gsm_1by3_5;

// Test Case : 1 

    a = 32;

    cycle_count[0] = Compute_Cycle_Count(d, output, a);
                            //This function inturn calls conv_gsm_1by3_5()
    for(i = 0; i < a; ++i)
    {
        error = (output[i] - exout[i]);
        if(error < 0)
            error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
            error_flag = error_flag | 1;
    }
    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
    #endif
    
    printf("cycle_count[0]=%d\n",cycle_count[0]);

}

