/*******************************************************************************
Copyright(c) 2000 - 2002 Analog Devices. All Rights Reserved.
Developed by Joint Development Software Application Team, IPDC, Bangalore, India
for Blackfin DSPs  ( Micro Signal Architecture 1.0 specification).

By using this module you agree to the terms of the Analog Devices License
Agreement for DSP Software. 
********************************************************************************
File Name      : test_conv_coder_gen.c
Description    : This file contains the testing routine for
                 conv_coder_gen()

*******************************************************************************/
#include <stdio.h>
#include "tconv_coder_gen.h"

int error_flag = 0;
void (*f1)();
int cycle_count[10];
void _conv_coder_gen();

main()
{
    int m, k, i, a, error;

    f1 = _conv_coder_gen;

// Test Case : 1 

    m = 3;
    a = 32;
    k = 2;

    cycle_count[0] = Compute_Cycle_Count(Cmn, d, m, k, output, a);        
                            //This function inturn calls conv_coder_gen()

    for(i = 0; i < a; ++i)
    {
        error = exout[i] - output[i];
        if(error < 0)
            error = -error;
        if(error > MAX_PERMISSIBLE_ERROR)
            error_flag = error_flag | 1;
    }

    #ifdef PRINTF_SUPPORT
        if(error_flag & 1)
            printf("Test Case 1 failed\n");
        else
            printf("Test Case 1 passed\n");
    #endif
    
    printf("cycle_count[0]=%d\n",cycle_count[0]);
    

}

